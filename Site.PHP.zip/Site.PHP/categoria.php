<?php
include 'conexao.php';
// Categoria escolhida pelo usuário (via URL)
$categoria_id = $_GET['categoria_id'];

// Busca produtos da categoria
$query = $conn->prepare("SELECT * FROM produtos WHERE categoria_id = :categoria_id");
$query->bindParam(':categoria_id', $categoria_id);
$query->execute();

while($produto = $query->fetch()) {
    echo "<h2>{$produto['nome']}</h2>";
    echo "<p>Preço: {$produto['preco']}</p>";
    echo "<img src='{$produto['imagem']}' alt='{$produto['nome']}'>";
}
?>
