<?php
include 'conexao.php';
session_start();

// Adicionar produto ao carrinho
$produto_id = $_GET['produto_id'];
$_SESSION['carrinho'][] = $produto_id;

// Exibir itens do carrinho
foreach($_SESSION['carrinho'] as $id) {
    $produto = $conn->query("SELECT * FROM produtos WHERE id = $id")->fetch();
    echo "<p>{$produto['nome']} - R$ {$produto['preco']}</p>";
}
?>
