<?php
try {
    $conn = new PDO('mysql:host=localhost;dbname=loja', 'usuario', 'senha');
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Conexão falhou: " . $e->getMessage();
}
?>
