<?php
include 'conexao.php';
// Conexão com o banco de dados
$conn = new PDO('mysql:host=localhost;dbname=loja', 'usuario', 'senha');

// Busca produtos em destaque
$query = $conn->query("SELECT * FROM produtos WHERE destaque = 1");

// Exibe produtos
while($produto = $query->fetch()) {
    echo "<h2>{$produto['nome']}</h2>";
    echo "<p>Preço: {$produto['preco']}</p>";
    echo "<img src='{$produto['imagem']}' alt='{$produto['nome']}'>";
}
?>
