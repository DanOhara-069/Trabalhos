<?php
include 'conexao.php';
// Registro de usuário
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);

    // Verifica se o email já existe
    $query = $conn->prepare("SELECT * FROM usuarios WHERE email = :email");
    $query->bindParam(':email', $email);
    $query->execute();

    if($query->rowCount() == 0) {
        // Insere novo usuário
        $stmt = $conn->prepare("INSERT INTO usuarios (email, senha) VALUES (:email, :senha)");
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':senha', $senha);
        $stmt->execute();
        echo "Usuário registrado com sucesso!";
    } else {
        echo "E-mail já cadastrado.";
    }
}
?>
